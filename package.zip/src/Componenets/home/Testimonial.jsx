export default function Testimonial() {
  return(
    <>
      <section class="info-section section-b-space">
        <div class="container">
            <div class="info-box" data-aos="fade-in" data-aos-duration="1000" data-aos-delay="100">
                <h2 class="text-white">Get Your Free Demo of AI TALK ASSIST Today!</h2>

                <button class="info-btn btn d-sm-inline-block" data-bs-toggle="modal" data-bs-target="#demo-modal">Book
                    a
                    Demo</button>
            </div>
        </div>
    </section>
    </>
  )
  
}